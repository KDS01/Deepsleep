package Stage1;

public class PaperProviso extends ChoiceObject {
	{
		this.choicename=" 바닥에 떨어진 종이 ";
		this.choiceObjectLines= new String[] {
				"\"어쩌면 이걸 잠금쇠 사이로 밀어넣으면 열 수 있지 않을까?\"",
				"그래, 얼마전에 봤던 첩보영화에서처럼 말이야. 종이의 빳빳한 부분을 이용해서 이렇게…",
				"\"그래…  될 리가 없지..\"",
				"방문의 작은 걸쇠도 아니고 무려 현관문의 자물쇠를 종이로 열 수 있을 리가 없다."
		
	};
	}

}
