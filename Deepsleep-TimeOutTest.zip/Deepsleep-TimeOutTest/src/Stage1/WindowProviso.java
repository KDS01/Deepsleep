package Stage1;

public class WindowProviso extends ChoiceObject {
	WindowProviso(){
		this.choicename="빌라 바깥";
		this.choiceObjectLines = new String[]
			{
			"열린 창문 너머로 작게 빌라 바깥쪽이 보인다.", 
			"바깥은 새까맣게 어둠이 내려앉아 묘하게 무서운 분위기를 풍긴다.",
			"빨리 집으로 들어가자"
			};
	}
}
