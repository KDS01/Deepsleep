package Stage1;

public class FrontDoorProviso extends ChoiceObject {
	{
		this.choicename="현관문";
		this.choiceObjectLines=new String[] {"늘 보던 현관문이다.",
				 " 이걸 빨리 열어야 집에 들어가서 쉴 수 있을텐데..."
				 }                                                                                                        ;
	}

}
