package Stage1;

public class LightProviso extends ChoiceObject {
	{
		this.choicename="형광등";
		this.choiceObjectLines=
				new String[] {
						"천장에서 희미한 형광등 불빛이 빛나고 있다.",
						"등을 교체할 때가 된 모양인지 가끔씩 깜빡깜빡 꺼졌다 켜지기를 반복하고 있다."
						};
	}

}
