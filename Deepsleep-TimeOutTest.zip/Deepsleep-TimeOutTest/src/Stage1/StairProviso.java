package Stage1;

public class StairProviso extends ChoiceObject {
	{
		this.choicename="계단";
		this.choiceObjectLines=new String[]
				{
				 "내가 올라온 계단이다.",
				"딱히 특별한 점은 보이지 않는다."
				};
}
}
