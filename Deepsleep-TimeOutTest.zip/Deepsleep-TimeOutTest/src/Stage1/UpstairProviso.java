package Stage1;

public class UpstairProviso extends ChoiceObject {
	{
		this.choicename ="계단 위쪽";
		this.choiceObjectLines = new String[] {
				"계단 위쪽에서는 아무런 소리도 들려오지 않는다.",
				" 누가 도와주지 않으려나.."
				};
	}

}
