package Stage1;

public class ClawHammerProviso extends ChoiceObject {
	{
		this.choicename="장도리";
		this.choiceObjectLines= new String[]
				{
				"뒷면에 못을 뽑을 수 있는 노루발 모양의 못뽑이가 달린 작은 망치.",
				" 크기는 작지만 통짜 철로 되어 있어 힘을 주어 때리면 상당한 파괴력을 내는 물건이다."
				};
		this.addProviso("단서 : 장도리");
	}

}
