package Stage1;

interface Stage1Interface {
	void provisoLines();
	

}
