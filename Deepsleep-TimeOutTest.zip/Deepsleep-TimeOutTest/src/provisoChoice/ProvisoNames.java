package provisoChoice;

import Stage1.ChoiceObject;

public class ProvisoNames extends ChoiceObject {
	


	public String[] Stage3Option = {
			"1.  조사한다\r\n",
			"2. 탈출한다\r\n"
	};
	public String[] stage3Proviso1 = {
			"1.  화장실\r\n",
			"2. 싱크대\r\n",
			"3. 안방 문\r\n",
			"4. 불길\r\n",
			"5. 현관문\r\n"
			};
	public String[] stage3Proviso2 = {
			"1.  전기 스토브\r\n",
			"2. 전기 포트\r\n",
			"3. 멀티탭\r\n",
			"4. 이불\r\n"
			};
}
