package Stage2;


public class ShoesRackProviso extends ChoiceObject2 {
	ShoesRackProviso(){
		this.choicename ="신발장";
		this.choiceObjectLines =new String[] 
				{
				"별다를 것 없는 신발장이다.",
				"열어봐도 딱히 특별한 것은 보이지 않는다."
				};
		
	}
	}

