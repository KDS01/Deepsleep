package Stage2;

import Stage1.ChoiceObject;

public class SofaProviso extends ChoiceObject2 {
	{
		this.choicename ="소파";
		this.choiceObjectLines =new String[] {
				"푹신해 보이는 소파다.",
				"당장이라도 달려가 눕고 싶지만 그 전에 해야할 일이...",
				"어..? 해야 할 일이 있었던가?"
				};
		}
	}
