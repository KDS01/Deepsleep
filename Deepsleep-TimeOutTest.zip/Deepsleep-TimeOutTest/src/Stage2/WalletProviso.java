package Stage2;


public class WalletProviso extends ChoiceObject2 {
	{
		this.choicename = "지갑";
		this.choiceObjectLines =new String[] {
				"카드와 신분증, 아주 소량의 현금이 들어있는 작은 지갑이다.",
				 "요새 현금 쓰는 사람 얼마 없으니까 굳이 현금은 들고 다니지 않는다..진짜로 ...",
				 "\"단서 : 지갑\"을 획득하셨습니다."
				};
		this.CombchoiceObjectLines = new String[] {
				"\"날 생각해내려면 당연히.....\"",
				"중얼거리면서 지갑을 집어들었다.",
				"여기에는 내 정보가 없을 수가 없지...",
				"유난히 작고 얇은 지갑을 열어보자,",
				"안에는 카드 한 개와 신분증이 들어있었다.",
				"\"신분증....그래..내 이름...내 이름은.....\"",
				"신분증에는 무표정한 내 증명사진 아래 \'한수연\'이라는 이름이 적혀있었다."
				};
//		this.addProviso("단서 : 지갑");
		
	}

}
