package Stage2;

public class RefregeratorProviso extends ChoiceObject2 {
	{
		this.choicename = "냉장고";
		this.choiceObjectLines = new String[] {
				"30년은 족히 된 것 같은 육중한 냉장고다.",
				"내 형편에 양문형 냉장고는 꿈도 꿀 수 없겠지.",
				"나보다 늙은 냉장고가 제대로 작동해주는 것만 해도 감사하다"
				};
		}
	}

