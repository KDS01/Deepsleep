package Stage2;


public class AbandonEcobagProviso extends ChoiceObject2 {
	{
		this.choicename="바닥에 내던져진 에코백";
		this.choiceObjectLines= new String[] {
				"오자마자 바닥에 던져버린 에코백이다. 별 게 안 들었음에도 묘하게 무거워서 어깨결림을 유발하는 장본인이다",
				"\' 단서 : 에코백 \' 이 추가되었습니다."};
		this.CombchoiceObjectLines = new String[] {
				"내용물을 다 쏟아내서 비어버린 에코백",
				"\"이건 이젠 별로  쓸모가 없겠는걸...\""
				};
	}

}

