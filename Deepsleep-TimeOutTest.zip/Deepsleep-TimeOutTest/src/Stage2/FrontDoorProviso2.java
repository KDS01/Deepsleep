package Stage2;


public class FrontDoorProviso2 extends ChoiceObject2 {
	{
		this.choicename="현관문";
		this.choiceObjectLines =new String[] {
				"내가 들어온 현관문이다.", 
				"도어락이 엉망으로 망가져있다.", 
				"아마도 다시 나갈 일은 더이상 없겠지..."
		};
	}
}


