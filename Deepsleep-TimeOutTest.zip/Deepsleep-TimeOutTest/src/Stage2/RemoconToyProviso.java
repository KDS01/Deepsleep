package Stage2;

public class RemoconToyProviso extends ChoiceObject2 {
	RemoconToyProviso() {
		this.choicename ="원격 조종 장난감";
		this.choiceObjectLines =new String[] 
				{
				"휴대폰과 연동해서 조종하는 작은 쥐 모양의 장난감이다.",
				"바닥에 바퀴가 달려있어 조종하는 대로 자유롭게 움직일 수 있다.",
				"\"이런 게 왜 우리 집에 있는거지...?\"",
				"\"단서 : 원격 조종 장난감\"을 획득하셨습니다."
				};
		this.CombchoiceObjectLines = new String[] {
				"\"이건...아무리 생각해봐도....\"",
				"쥐 모양의 장난감에.. 휴대폰을 연동해서 움직이는....",
				"\"전형적인 고양이 장난감이잖아....\"",
				"생각해내자.... 생각해내자.....",
				"내가 키웠던 고양이.... 내가 키웠던 고양이는...",
				"먹구름이 잔뜩 낀 머릿속을 헤집으며 생각하는 도중",
				"마치 먹구름속에 전구가 켜지듯 번쩍 생각이 떠올랐다",
				"\"마루.... 그래..우리 마루...\""
				};
}
}
