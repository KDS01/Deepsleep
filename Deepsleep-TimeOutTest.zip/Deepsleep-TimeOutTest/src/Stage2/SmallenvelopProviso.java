package Stage2;


public class SmallenvelopProviso extends ChoiceObject2 {
	{
		this.choicename = "작은 봉투";
		this.choiceObjectLines = new String[] {
				"무엇이 들어있는지 모를 작은 봉투다.",
				"언제부터 내 가방에 있었더라.. 뭐가 들어있을 지 모르니 조심스럽게 열어보자",
				"부스럭 부스럭..",
				"봉투를 헤집자 작은 약통이 툭 하고 떨어졌다.",
				"보통의 약통 크기가 크지 않은 걸 감안해도, 상당히 작은 크기의 약통이었다.",
				"내가 평소에 먹었던 약인가보다..",
				"약통에는 작은 네이밍 태그가 붙어있었다.",
				"네이밍 태그에는 \'티오펜탈나트륨\'이라고 적혀있었다.",
				"\'단서 : 티오펜탈나트륨\'을 획득하셨습니다."
				};
//		this.addProviso("단서 : 티오펜탈나트륨");
		}
	}
