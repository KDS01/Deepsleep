package Stage3;

import Stage2.ChoiceObject2;

public class ToiletProviso extends ChoiceObject2 {
	{
		this.choicename = "화장실";
		this.choiceObjectLines = new String[] { 
				"문이 굳게 닫혀있는 화장실이다.",
				"열어보고 싶지만 용을 써도 도저히 열리질 않는다."
				};
		}
	}

