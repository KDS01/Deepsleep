package Stage3;

import Stage2.ChoiceObject2;

public class SinkProviso extends ChoiceObject2 {
	{
		this.choicename = "싱크대";
		this.choiceObjectLines =new String[] {
				"타오르는 불을 조심조심 피해가며 싱크대로 달려갔다",
				"일단 물을 틀어서 불을 끄자",
				"생각하며 수도꼭지를 최대로 열었지만 물은 나오지 않았다",
				"이럴 시간이 없는데.."
				};
	}

}

	

