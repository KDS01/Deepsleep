package Stage3;

import Stage2.ChoiceObject2;

public class MultitapProviso extends ChoiceObject2 {
	{
		this.choicename = "멀티탭";
		this.choiceObjectLines = new String[] {
				"가정용 멀티탭 여러 개가 한 멀티탭에 난잡하게 꽂혀 있다.",
				"이건 완전 문어발이 따로 없네..",
				"\"단서 : 문어발\"을 획득하셨습니다."
				};
//		this.addProviso("단서 : 문어발");
		this.CombchoiceObjectLines = new String[] {
				"하나의 멀티탭에 난잡하게 꽂혀있는 여러개의 멀티탭.",
				"거기에다가 새까맣게 이어져있는 불 탄 자국들은....",
				"여기서부터 무슨 일이 벌어졌다는 걸 암시하는 듯 했다."
		};
	}

}
