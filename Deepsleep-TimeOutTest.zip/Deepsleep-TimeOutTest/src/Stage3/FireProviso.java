package Stage3;

import Stage2.ChoiceObject2;

public class FireProviso extends ChoiceObject2 {
	{
		this.choicename = "불길";
		this.choiceObjectLines = new String[] {
				"시뻘겋게 불길이 혓바닥을 낼름거리며 타오르고 있다.",
				"이걸 빨리 어떻게든 해야 해..!"
				};
	}

}

