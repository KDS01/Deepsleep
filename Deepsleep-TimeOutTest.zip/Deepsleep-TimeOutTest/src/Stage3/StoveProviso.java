package Stage3;

import Stage2.ChoiceObject2;

public class StoveProviso extends ChoiceObject2 {
	{
	this.choicename = "전기 스토브";
	this.choiceObjectLines = new String[] {
			"흔히 볼 수 있는 가정용 전기 스토브.",
			"문제없이 잘 작동하고 있다."};
	}

	}
