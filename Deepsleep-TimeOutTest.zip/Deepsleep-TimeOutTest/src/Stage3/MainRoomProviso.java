package Stage3;

import Stage2.ChoiceObject2;

public class MainRoomProviso extends ChoiceObject2 {
	{
		this.choicename = "안방";
		this.choiceObjectLines = new String[] {
				"무의식적으로 안방으로 시선이 향했을 때, 갑자기 위화감이 들었다",
				"온 집안이 불길에 타오르고 있는데... 안방은 마치 다른 공간인 것 처럼 불길이 침입하지 못하고 있다.",
				"뇌를 파고드는 이 기묘한 위화감에 의문을 품을 새도 없이, 뒤쪽에서 잿더미가 된 식탁이 요란한 소리를 내며 무너져 내렸다.",
				"\"지금은 생각하고 있을 시간이 없어...\"",
				"혼자 나직하게 중얼거리며 안방으로 발걸음을 옮겼다.",
				"\'단서 : 안방\' 을 획득하셨습니다."
				};
//		this.addProviso("단서 : 안방");
}
}
