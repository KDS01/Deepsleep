package Stage3;

import Stage2.ChoiceObject2;

public class Frontdoor3Proviso extends ChoiceObject2 {
	{
		this.choicename = "현관문";
		this.choiceObjectLines = new String[] {
				"당장이라도 문을 박차고 나가고 싶지만, 그래서는 안 될 것 같은 기분이 강하게 든다.",
				"시간이 없다. 어서 집 안을 더 조사해보자"}
		;
	}

}


