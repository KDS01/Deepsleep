package Stage3;

import Stage2.ChoiceObject2;

public class PotProviso extends ChoiceObject2 {
	{
		this.choicename = "전기 포트";
		this.choiceObjectLines = new String[] {
				"컵라면에 올릴 물을 넣기 딱 좋은 크기의 전기 포트.",
				"오랫동안 사용하지 못한 듯 바닥이 완전히 말라붙어 있다"
	};
	}

}
