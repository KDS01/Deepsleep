package deepsleep;

import Stage1.Stage1Flow;
import Stage2.Stage2Flow;
import Stage3.Stage3Flow;
import Stage4.Stage4Flow;

public class Flow extends Thread {
	public void allflow() {
		Stage1Flow s1Flow = new Stage1Flow();
		Stage2Flow s2Flow = new Stage2Flow();
		Stage3Flow s3Flow = new Stage3Flow();
		Stage4Flow s4Flow = new Stage4Flow();
		System.out.println("Deep Sleep....");
		System.out.println("계속하려면 아무 키나 입력하세요.");
		s1Flow.S1Start();
		s1Flow.S1provisoInput1();
		s1Flow.S1ORG();
		s1Flow.S1provisoInput2();
		s1Flow.S1End();
		s2Flow.s2Flows();
		s3Flow.S3Start();
		s3Flow.S3FirstChoice(s2Flow);
		s3Flow.S3provisoInput2(s2Flow);
		s3Flow.S3provisoInput3(s2Flow);
		s3Flow.S3ORG();
		s3Flow.S3provisoInput4(s2Flow);
		s4Flow.S4start(s2Flow);
		s4Flow.S4Input(s2Flow);
		s4Flow.isTrueEnding(s2Flow);
	}
}