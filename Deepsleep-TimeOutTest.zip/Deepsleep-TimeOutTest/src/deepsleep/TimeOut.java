package deepsleep;

import java.util.Timer;
import java.util.TimerTask;

public class TimeOut extends Thread{// extends Thread {
//	Timer timer = new Timer();
//	BadEnding be = new BadEnding();
//	TimerTask task = new TimerTask() {
//		@Override
		Timer timer = new Timer();
			@Override
			public void run() {
				try {
				Flow flow = new Flow();
				Narrator nar = new Narrator();
				EndingLines ed = new EndingLines();
				Thread.sleep(60000);
				flow.sleep(50000);
				nar.NameNarration(ed.badEnding);
				Thread.
				System.exit(0);
			}catch(Exception e) {
				e.printStackTrace();
				}
			}
//				try {
//					long delay=600000;
//					timer.schedule(task, delay);
////					Thread.sleep(600000);
//					be.badEnd();
//					task.cancel();
//				}catch(Exception e) {
//					e.printStackTrace();
//				}
	}

	
	
	
//}
//class BadEnding {
//	Narrator nar = new Narrator();
//	EndingLines ed = new EndingLines();
//	void badEnd() {
//		nar.NameNarration(ed.badEnding);
//		System.exit(0);
//	}
//	
//}
