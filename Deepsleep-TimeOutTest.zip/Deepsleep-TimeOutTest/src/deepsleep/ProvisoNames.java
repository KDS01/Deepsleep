package deepsleep;

public class ProvisoNames {
	
	public String stage1Proviso1 =
			"1.  계단\r\n"
			+ "2. 형광등\r\n"
			+ "3. 바닥에 떨어진 종이\r\n"
			+ "4. 빌라 바깥\r\n"
			+ "5. 계단 위쪽\r\n"
			+ "6. 현관문\r\n"
			+ "7. 도어락\r\n";
	public String stage1Proviso2 =
			"1.  계단\r\n"
			+ "2. 형광등\r\n"
			+ "3. 바닥에 떨어진 종이\r\n"
			+ "4. 빌라 바깥\r\n"
			+ "5. 계단 위쪽\r\n"
			+ "6. 현관문\r\n"
			+ "7. 도어락\r\n"
			+ "8. 장도리\r\n";
	public String stage2Proviso1 =
			"1.  신발장\r\n"
			+ "2. 소파\r\n"
			+ "3. 냉장고\r\n"
			+ "4. 바닥에 내던져진 에코백\r\n"
			+ "5. 에어컨\r\n"
			+ "6. 현관문\r\n";
	public String stage2Proviso2 =
			"1.  신발장\r\n"
			+ "2. 소파\r\n"
			+ "3. 냉장고\r\n"
			+ "4. 바닥에 내던져진 에코백\r\n"
			+ "5. 에어컨\r\n"
			+ "6. 현관문\r\n"
			+ "7. 원격 조종 장난감";
	public String ecobag =
			"1.  지갑\r\n"
			+ "2. 휴대폰\r\n"
			+ "3. 작은 봉투\r\n";
	public String Stage2Option =
			"1.  문을 열어본다\r\n"
			+ "2. 문을 두드린다\r\n";
	
	public String Stage3Option =
			"1.  조사한다\r\n"
			+ "2. 탈출한다\r\n";
	public String stage3Proviso1 =
			"1.  화장실\r\n"
			+ "2. 싱크대\r\n"
			+ "3. 안방 문\r\n"
			+ "4. 불길\r\n"
			+ "5. 현관문\r\n";
	public String stage3Proviso2 =
			"1.  전기 스토브\r\n"
			+ "2. 전기 포트\r\n"
			+ "3. 멀티탭\r\n"
			+ "4. 이불\r\n";
}
