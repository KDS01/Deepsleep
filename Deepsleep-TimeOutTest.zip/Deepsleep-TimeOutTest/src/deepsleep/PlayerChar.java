package deepsleep;

public class PlayerChar {
	public String playerName= "???";
	public String trueName="한수연";

}
