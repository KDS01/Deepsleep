package deepsleep;
import Stage1.*;
import Stage2.*;
import Stage3.*;
import Stage4.*;
import java.util.Scanner;
public class Main extends Stage1Flow {
	public static void main(String[] args) {
		TimeOut to = new TimeOut();
		Flow flow = new Flow();
		to.run();
		flow.allflow();
	}
}