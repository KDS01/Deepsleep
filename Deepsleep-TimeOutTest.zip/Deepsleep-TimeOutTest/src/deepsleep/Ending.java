package deepsleep;

public class Ending {
	public void badEnding()
	{
		
	}
	public void badEnding2()
	{
		
	}
	public void normalEnding()
	{
		
	}
	public void normalEnding2()
	{
		
	}
	public void trueEnding()
	{
		
	}
}

	
